export { default as dashboardRoutes } from '@/pages/dashboard/dashboard-routes';
