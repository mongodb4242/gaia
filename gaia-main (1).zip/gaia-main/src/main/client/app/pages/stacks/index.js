export { default as stacksRoutes } from '@/pages/stacks/stacks-routes';
