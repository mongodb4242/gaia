export { default as loginRoutes } from '@/pages/login/login-routes';
