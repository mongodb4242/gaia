export { default as credentialsRoutes } from '@/pages/credentials/credentials-routes';
