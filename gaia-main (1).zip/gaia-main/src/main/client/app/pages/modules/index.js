export { default as modulesRoutes } from '@/pages/modules/modules-routes';
