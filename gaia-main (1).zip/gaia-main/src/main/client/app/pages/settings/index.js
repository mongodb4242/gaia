export { default as settingsRoutes } from '@/pages/settings/settings-routes';
