package io.gaia_app.stacks.workflow.state;

/**
 * Describes a job which apply has been finished
 */
public class ApplyFinishedState implements JobState {
}
