package io.gaia_app.stacks.bo;

public enum StepStatus {
    PENDING, STARTED, FINISHED, FAILED
}
