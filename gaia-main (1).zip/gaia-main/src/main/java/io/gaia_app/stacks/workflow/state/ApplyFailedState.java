package io.gaia_app.stacks.workflow.state;

/**
 * Describes a job which apply has been failed
 */
public class ApplyFailedState extends RetryableState {
}
