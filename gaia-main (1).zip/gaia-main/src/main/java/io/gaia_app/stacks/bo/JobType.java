package io.gaia_app.stacks.bo;

public enum JobType {
    RUN, DESTROY
}
