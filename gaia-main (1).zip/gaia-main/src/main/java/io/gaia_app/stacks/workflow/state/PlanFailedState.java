package io.gaia_app.stacks.workflow.state;

/**
 * Describes a job which plan has been failed
 */
public class PlanFailedState extends RetryableState {
}
