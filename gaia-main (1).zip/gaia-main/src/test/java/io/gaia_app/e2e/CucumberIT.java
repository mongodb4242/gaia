package io.gaia_app.e2e;

import io.cucumber.junit.platform.engine.Cucumber;

/**
 * This is a marker class for surefire-engine to help it detect that it needs to run cucumber
 */
@Cucumber
public class CucumberIT {
}
